class Package:

    def __init__(self,message,body=None):
        self.message = message
        self.body = body